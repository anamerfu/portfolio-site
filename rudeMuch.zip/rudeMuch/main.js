

$( document ).ready(function() {


var responseText = "<li class ='output' id = 'botOutput'> Bot output </li>";
var latestUserInput = "";
var username = "3c598690-f089-4a0f-870b-dab9de7035c9";
var password = "sbeqqW8ZdpTw";
/*
$.getJSON({
    'url': 'https://gateway.watsonplatform.net/tone-analyzer/api/v3/tone?version=2017-09-21&text=Team,%20I%20know%20that%20times%20are%20tough!%20Product%20sales%20have%20been%20disappointing%20for%20the%20past%20three%20quarters.%20We%20have%20a%20competitive%20product,%20but%20we%20need%20to%20do%20a%20better%20job%20of%20selling%20it!',
    'otherSettings': 'othervalues',
    'beforeSend': function(xhr) {
        //May need to use "Authorization" instead
        xhr.setRequestHeader("Authorization",
            "Basic " + btoa(username + ":" + password))
    },
    success: function(result) {
        alert('done');
    }

});
*/

/*
;$.ajax({
    url: "https://gateway.watsonplatform.net/tone-analyzer/api/v3/tone?version=2017-09-21&text=Team,%20I%20know%20that%20times%20are%20tough!%20Product%20sales%20have%20been%20disappointing%20for%20the%20past%20three%20quarters.%20We%20have%20a%20competitive%20product,%20but%20we%20need%20to%20do%20a%20better%20job%20of%20selling%20it!",
    beforeSend: function(xhr) {
        xhr.setRequestHeader("Authorization", "Basic " + window.btoa(username + ":" + password));
    },
    xhrFields: {
      withCredentials: true
    },

    success: function(result) {
        console.log(arguments);
    }
});
*/
$('#sendButton').click(function(){

  //prevent page from refreshing on submit
  $("#messageForm").submit(function(e) {
    e.preventDefault();
  });

 //store the user's entry in a variable
 latestUserInput = document.getElementById('userInput').value;
 console.log(latestUserInput)

 //append bot message
 if (latestUserInput !== "") {
   $( "#outputArea" ).append(responseText);
 } else {
   console.log("input was blank");
 }


});

});
