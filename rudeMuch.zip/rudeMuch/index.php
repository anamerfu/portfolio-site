
  <?php
//endpoint
$endpoint = "https://gateway.watsonplatform.net/tone-analyzer/api/v3/tone?version=2016-05-19";
$username='3c598690-f089-4a0f-870b-dab9de7035c9';
$password='sbeqqW8ZdpTw';

$userInput = $_GET['userInput'];

$data = json_encode(array('text' => "$userInput"));


// Initialize cURL
$curl = curl_init();

// Set cURL options
curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
curl_setopt( $curl, CURLOPT_URL, $endpoint );
curl_setopt($curl, CURLOPT_USERPWD, "$username:$password");
curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_ANY);


// Execute the cURL request
$result = curl_exec( $curl );


// Close the cURL instance
curl_close( $curl );


//convert result to an Array
$result = json_decode($result, true);

$tonesArrayPlace = $result['document_tone']['tone_categories'][0]['tones'] ;

$tonesArray = array(
  "anger" => $tonesArrayPlace[0]['score'],
  "disgust" => $tonesArrayPlace[1]['score'],
  "fear" => $tonesArrayPlace[2]['score'],
  "joy" => $tonesArrayPlace[3]['score'],
  "sadness" => $tonesArrayPlace[4]['score'],
);

$strongestToneValue = max($tonesArray);
$strongestTone = array_search($strongestToneValue, $tonesArray);


$answer = function($tone, $value) {
  if ($tone == 'anger' && $value > 0.75 ) {
    return "You should probably take some deep breaths and a Zoloft, you psycho.";
  } elseif  ($tone == 'anger' && $value > 0.50 && $value < 0.75) {
    return "Rude much? You clearly have an attitude problem. Maybe do some yoga, or have a martini.";
  } elseif ($tone == 'disgust' && $value > 0.75){
    return "What? Is this conversation disgusting to you? Do I disgust you? DO I?!";
  } elseif ($tone == 'disgust' && $value > 0.50 && $value < 0.75){
    return "My radar senses disgust or something. If you don't want to be around me, fine, whatever.";
  } elseif ($tone == 'fear' && $value > 0.75) {
    return "Can you seriously relax? You're killing my vibe.";
  } elseif($tone == 'fear' && $value > 0.50 && $value < 0.75) {
    return "Seems like something's bothering you.. sucks to be you!";
  } elseif ($tone == 'joy' && $value > 0.75) {
    return "Woah, someone's in a good mood today! Almost too nice.. you've been drinking, haven't you?";
  } elseif ($tone == 'joy' && $value > 0.50 && $value < 0.75) {
    return "Hey, you could fool someone into thinking you're a nice person! Good for you!";
  } elseif ($tone == 'sadness' && $value > 0.75 ) {
    return "Gosh, you seem really upset... Gosh look at the time! Feel better soon!";
  } elseif ($tone == 'sadness' && $value > 0.50 && $value < 0.75) {
    return "You're villing me vibe... let's chat when you're more fun to be around.";
  } else {
    return "You have the emotional range of a corn flake. *yawn*";
  }

};

?>


<html>
  <head>
    <meta charset="utf-8" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <link rel="stylesheet" href="style.css"  />
    <title>Rude Much</title>

  </head>
  <body>

    <main class="container">
      <div class="row">
        <div id="title" class= "col-sm-12">
          <h1>Rude much?</h1>
          <h2>Send Rudith a message before you send it to a real person. </h2>
        </div>
      </div>

        <div id="messageArea" class="row">
          <div class= "col-sm-12 text-center">
            <form id="messageForm" action="index.php" method="get">
              <textarea id = "userInput" name = "userInput" placeholder="Talk to me!"></textarea>
          </div>
          <div class= "col-sm-12 text-center">
              <button class="sendButton" name = "send" type="submit" value="Send">Send</button>
          </div>
            </form>

        </div>

        <div id = "outputArea" class="row">
          <div id="botOutput" class="col-sm-12 text-center">
            <h3>
              <?php
              if(isset($_GET['send'])) {
                print_r($answer($strongestTone, $strongestToneValue));
              };
              ?>
            </h3>
        </div>
      </div>

    </main>
  </body>

</html>
